import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const welcomes = pgTable("welcomes", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  avatarUrl: text("avatar_url").notNull(),
  memberCount: integer("member_count").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertWelcomeSchema = createInsertSchema(welcomes).omit({ 
  id: true, 
  createdAt: true 
});

export type Welcome = typeof welcomes.$inferSelect;
export type InsertWelcome = z.infer<typeof insertWelcomeSchema>;

export type GenerateWelcomeRequest = {
  username: string;
  avatarUrl: string;
  memberCount: string | number; // Allow string from query params
  theme?: 'dark' | 'light';
};

import { z } from 'zod';
import { insertWelcomeSchema, welcomes } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  welcome: {
    generate: {
      method: 'GET' as const,
      path: '/api/welcome',
      input: z.object({
        username: z.string(),
        avatarUrl: z.string().url(),
        memberCount: z.string().or(z.number()).transform(val => Number(val)),
        theme: z.enum(['dark', 'light']).optional().default('dark'),
      }),
      responses: {
        200: z.any(), // Returns binary image data
        400: errorSchemas.validation,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/history',
      responses: {
        200: z.array(z.custom<typeof welcomes.$inferSelect>()),
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type GenerateWelcomeInput = z.infer<typeof api.welcome.generate.input>;

import { db } from "./db";
import {
  welcomes,
  type InsertWelcome,
  type Welcome
} from "@shared/schema";
import { desc } from "drizzle-orm";

export interface IStorage {
  createWelcomeLog(welcome: InsertWelcome): Promise<Welcome>;
  getRecentWelcomes(limit?: number): Promise<Welcome[]>;
}

export class DatabaseStorage implements IStorage {
  async createWelcomeLog(welcome: InsertWelcome): Promise<Welcome> {
    const [newWelcome] = await db
      .insert(welcomes)
      .values(welcome)
      .returning();
    return newWelcome;
  }

  async getRecentWelcomes(limit = 10): Promise<Welcome[]> {
    return await db
      .select()
      .from(welcomes)
      .orderBy(desc(welcomes.createdAt))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();

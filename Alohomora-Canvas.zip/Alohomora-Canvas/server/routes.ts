import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { join } from "path";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // GET /api/welcome
  app.get(api.welcome.generate.path, async (req, res) => {
    try {
      // 1. Validate Input
      // We parse query params here. Zod handles coercion if configured, but query params are strings.
      // In shared/routes, I used .transform(val => Number(val)) which works on the result of parsing.
      // But req.query values are strings.
      const rawInput = {
        username: req.query.username,
        avatarUrl: req.query.avatarUrl,
        memberCount: req.query.memberCount,
        theme: req.query.theme || 'dark',
      };
      
      const input = api.welcome.generate.input.parse(rawInput);

      // 2. Log the generation (fire and forget, or await)
      await storage.createWelcomeLog({
        username: input.username,
        avatarUrl: input.avatarUrl,
        memberCount: input.memberCount,
      });

      // 3. Canvas Setup
      const width = 800;
      const height = 350; // Compact height
      const canvas = createCanvas(width, height);
      const ctx = canvas.getContext('2d');

      // 4. Background (Apple Glass Style)
      // Dark mode: dark gradients with noise/blur feel
      const isDark = input.theme === 'dark';
      
      // Gradient background
      const gradient = ctx.createLinearGradient(0, 0, width, height);
      if (isDark) {
        gradient.addColorStop(0, '#0f0c29');
        gradient.addColorStop(0.5, '#302b63');
        gradient.addColorStop(1, '#24243e');
      } else {
        gradient.addColorStop(0, '#e0c3fc');
        gradient.addColorStop(1, '#8ec5fc');
      }
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Glass Card
      // We'll draw a rounded rect in the center with low opacity
      const cardX = 40;
      const cardY = 40;
      const cardW = width - 80;
      const cardH = height - 80;
      const radius = 24;

      ctx.save();
      ctx.beginPath();
      ctx.roundRect(cardX, cardY, cardW, cardH, radius);
      ctx.fillStyle = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(255, 255, 255, 0.4)';
      ctx.fill();
      // Border for glass effect
      ctx.lineWidth = 1;
      ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.2)' : 'rgba(255, 255, 255, 0.6)';
      ctx.stroke();
      
      // Add subtle shadow/glow
      ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
      ctx.shadowBlur = 20;
      ctx.shadowOffsetY = 10;
      ctx.restore();

      // 5. User Avatar
      // Circular mask
      const avatarSize = 140;
      const avatarX = cardX + 50;
      const avatarY = height / 2 - avatarSize / 2;

      try {
        const avatar = await loadImage(input.avatarUrl);
        ctx.save();
        ctx.beginPath();
        ctx.arc(avatarX + avatarSize/2, avatarY + avatarSize/2, avatarSize/2, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
        ctx.restore();
        
        // Avatar Ring
        ctx.beginPath();
        ctx.arc(avatarX + avatarSize/2, avatarY + avatarSize/2, avatarSize/2, 0, Math.PI * 2);
        ctx.lineWidth = 4;
        ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.9)';
        ctx.stroke();

      } catch (e) {
        console.error("Failed to load avatar:", e);
        // Fallback circle
        ctx.beginPath();
        ctx.arc(avatarX + avatarSize/2, avatarY + avatarSize/2, avatarSize/2, 0, Math.PI * 2);
        ctx.fillStyle = '#ccc';
        ctx.fill();
      }

      // 6. Text Content
      const textX = avatarX + avatarSize + 40;
      const textCenterY = height / 2;
      
      // "Welcome to Alohomora server!"
      ctx.font = isDark ? '24px sans-serif' : '24px sans-serif'; // Simple font fallback
      ctx.fillStyle = isDark ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)';
      ctx.fillText("Welcome to Alohomora server!", textX, textCenterY - 35);

      // Username
      ctx.font = 'bold 48px sans-serif';
      ctx.fillStyle = isDark ? '#ffffff' : '#000000';
      ctx.fillText(input.username, textX, textCenterY + 15);

      // Member Count Badge
      const countText = `Member #${input.memberCount}`;
      ctx.font = '18px sans-serif';
      const countMetrics = ctx.measureText(countText);
      const badgePadding = 12;
      const badgeW = countMetrics.width + (badgePadding * 2);
      const badgeH = 32;
      const badgeX = textX;
      const badgeY = textCenterY + 35;

      // Badge Background
      ctx.beginPath();
      ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 16);
      ctx.fillStyle = isDark ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.1)';
      ctx.fill();
      
      // Badge Text
      ctx.fillStyle = isDark ? '#ffffff' : '#000000';
      ctx.fillText(countText, badgeX + badgePadding, badgeY + 22);

      // 7. Output
      const buffer = await canvas.encode('png');
      res.set('Content-Type', 'image/png');
      res.send(buffer);

    } catch (err) {
      console.error(err);
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      } else {
        res.status(500).json({ message: "Failed to generate welcome image" });
      }
    }
  });

  // GET /api/history
  app.get(api.welcome.list.path, async (req, res) => {
    const recents = await storage.getRecentWelcomes();
    res.json(recents);
  });

  return httpServer;
}

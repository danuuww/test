import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

// We don't really have a 'create' mutation because the image is generated via GET request.
// However, we might want to fetch history if we implemented storing it.
// The backend route '/api/history' exists in the schema provided.

export function useWelcomeHistory() {
  return useQuery({
    queryKey: [api.welcome.list.path],
    queryFn: async () => {
      const res = await fetch(api.welcome.list.path);
      if (!res.ok) throw new Error("Failed to fetch history");
      return api.welcome.list.responses[200].parse(await res.json());
    },
  });
}

// Helper to construct the image URL for the frontend to use in <img> tags
export function getWelcomeImageUrl(params: { username: string; avatarUrl: string; memberCount: string | number; theme?: 'dark' | 'light' }) {
  const searchParams = new URLSearchParams({
    username: params.username,
    avatarUrl: params.avatarUrl,
    memberCount: String(params.memberCount),
    theme: params.theme || 'dark'
  });
  
  return `${api.welcome.generate.path}?${searchParams.toString()}`;
}

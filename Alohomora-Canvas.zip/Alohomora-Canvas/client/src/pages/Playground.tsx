import { useState } from "react";
import { motion } from "framer-motion";
import { GlassCard } from "@/components/GlassCard";
import { Input } from "@/components/Input";
import { Button } from "@/components/Button";
import { getWelcomeImageUrl } from "@/hooks/use-welcome";
import { Copy, RefreshCw, Download, Sparkles, Image as ImageIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";

// Default preset avatars to make testing easy
const PRESET_AVATARS = [
  "https://github.com/shadcn.png",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix",
  "https://api.dicebear.com/7.x/bottts/svg?seed=Aneka",
  "https://api.dicebear.com/7.x/lorelei/svg?seed=Sasha",
];

export default function Playground() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    username: "Alohomora User",
    avatarUrl: PRESET_AVATARS[0],
    memberCount: "420",
    theme: "dark" as "dark" | "light"
  });
  
  const [generatedUrl, setGeneratedUrl] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);

  // Generate URL on mount or initially
  const handleGenerate = () => {
    setIsGenerating(true);
    // Simulate a brief loading state for better UX feeling
    setTimeout(() => {
      const url = getWelcomeImageUrl({
        username: formData.username,
        avatarUrl: formData.avatarUrl,
        memberCount: formData.memberCount,
        theme: formData.theme
      });
      setGeneratedUrl(url);
      setIsGenerating(false);
      
      toast({
        title: "Canvas Generated",
        description: "Your welcome image is ready to preview.",
      });
    }, 600);
  };

  const copyUrl = () => {
    if (!generatedUrl) return;
    const fullUrl = window.location.origin + generatedUrl;
    navigator.clipboard.writeText(fullUrl);
    toast({
      title: "URL Copied!",
      description: "Paste this link into your Discord bot config.",
    });
  };

  return (
    <div className="min-h-screen w-full px-4 py-12 md:py-20 max-w-7xl mx-auto flex flex-col items-center">
      
      {/* Header Section */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16 space-y-4 max-w-2xl"
      >
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-semibold uppercase tracking-wider mb-4">
          <Sparkles className="w-3 h-3" />
          Premium Canvas API
        </div>
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
          <span className="text-white">Discord</span> <span className="text-gradient-primary">Welcomer</span>
        </h1>
        <p className="text-lg text-muted-foreground/80 leading-relaxed">
          Create stunning, dynamic welcome images for your Discord community. 
          Apple-style glassmorphism aesthetics, auto-generated instantly.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full">
        
        {/* Controls Column */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="lg:col-span-4 space-y-6"
        >
          <GlassCard className="h-full">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-primary/20 text-primary">
                <RefreshCw className="w-5 h-5" />
              </div>
              <h2 className="text-xl font-semibold text-white">Configuration</h2>
            </div>
            
            <div className="space-y-6">
              <Input
                label="Username"
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                placeholder="e.g. Wizard#1234"
              />
              
              <div className="space-y-3">
                <label className="text-sm font-medium text-muted-foreground ml-1">
                  User Avatar
                </label>
                <div className="grid grid-cols-4 gap-2 mb-2">
                  {PRESET_AVATARS.map((url, i) => (
                    <button
                      key={i}
                      onClick={() => setFormData({...formData, avatarUrl: url})}
                      className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                        formData.avatarUrl === url 
                          ? "border-primary ring-2 ring-primary/20" 
                          : "border-transparent hover:border-white/20"
                      }`}
                    >
                      <img src={url} alt="avatar" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
                <Input
                  value={formData.avatarUrl}
                  onChange={(e) => setFormData({...formData, avatarUrl: e.target.value})}
                  placeholder="https://..."
                  className="text-xs font-mono"
                />
              </div>

              <Input
                label="Member Count"
                type="number"
                value={formData.memberCount}
                onChange={(e) => setFormData({...formData, memberCount: e.target.value})}
                placeholder="e.g. 1500"
              />
              
              <div className="space-y-2">
                 <label className="text-sm font-medium text-muted-foreground ml-1">
                  Theme
                </label>
                <div className="grid grid-cols-2 gap-3 p-1 bg-black/20 rounded-xl">
                  {['dark', 'light'].map((theme) => (
                    <button
                      key={theme}
                      onClick={() => setFormData({...formData, theme: theme as 'dark' | 'light'})}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                        formData.theme === theme 
                          ? "bg-primary text-white shadow-lg shadow-primary/20" 
                          : "text-muted-foreground hover:text-white"
                      }`}
                    >
                      {theme.charAt(0).toUpperCase() + theme.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4">
                <Button 
                  className="w-full h-14 text-base" 
                  onClick={handleGenerate}
                  loading={isGenerating}
                >
                  Generate Canvas
                </Button>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Preview Column */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="lg:col-span-8 flex flex-col h-full"
        >
          <GlassCard className="flex-1 flex flex-col items-center justify-center min-h-[400px] relative">
            <div className="absolute top-6 left-8 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                <ImageIcon className="w-5 h-5" />
              </div>
              <h2 className="text-xl font-semibold text-white">Live Preview</h2>
            </div>

            <div className="w-full max-w-2xl aspect-[2/1] relative rounded-xl overflow-hidden shadow-2xl bg-black/50 border border-white/5 flex items-center justify-center group">
              {generatedUrl ? (
                <img 
                  src={generatedUrl} 
                  alt="Welcome Preview" 
                  key={Date.now()} // Force re-render to prevent caching issues during frequent updates
                  className="w-full h-full object-contain transition-transform duration-700 hover:scale-[1.02]"
                />
              ) : (
                <div className="text-center space-y-3">
                  <div className="w-16 h-16 rounded-full bg-white/5 mx-auto flex items-center justify-center">
                    <Sparkles className="w-8 h-8 text-white/20" />
                  </div>
                  <p className="text-muted-foreground">Click generate to see the magic</p>
                </div>
              )}
            </div>

            {generatedUrl && (
              <div className="mt-8 flex flex-col sm:flex-row gap-4 w-full max-w-lg">
                <Button variant="glass" className="flex-1 gap-2" onClick={copyUrl}>
                  <Copy className="w-4 h-4" />
                  Copy API Link
                </Button>
                <Button variant="glass" className="flex-1 gap-2" onClick={() => window.open(generatedUrl, '_blank')}>
                  <Download className="w-4 h-4" />
                  Open Raw Image
                </Button>
              </div>
            )}
          </GlassCard>
          
          <div className="mt-8 p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-sm">
            <h3 className="text-lg font-medium text-white mb-2">API Usage</h3>
            <code className="block bg-black/40 rounded-lg p-4 text-xs md:text-sm font-mono text-muted-foreground break-all hover:text-primary-foreground transition-colors cursor-text">
              {window.location.origin}{api.welcome.generate.path}?username=User&avatarUrl=...&memberCount=100
            </code>
          </div>
        </motion.div>

      </div>
    </div>
  );
}

import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
}

export function GlassCard({ children, className }: GlassCardProps) {
  return (
    <div className={cn(
      "glass-card rounded-3xl p-6 sm:p-8 relative overflow-hidden group",
      className
    )}>
      {/* Subtle shine effect on hover */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      {/* Border gradient */}
      <div className="absolute inset-0 rounded-3xl border border-white/10 pointer-events-none" />
      
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}
